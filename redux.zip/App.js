
import './App.css';
import { Routes, Route, NavLink } from 'react-router-dom';
import ItemList from './services/ItemList';
import  Readmore from './component/Readmore';


function App() {

  return (
    <div>
    <div className="App">
    <h2>Redux Library</h2>
     <NavLink to="/">Home</NavLink>
     <NavLink to="/itemlist">Item List</NavLink>
 
    <hr/>
    </div>
  
 
   
    
    <Routes>
    
       <Route path='/itemlist' element={<ItemList/>}></Route>
      <Route path="/readmore/:id" element={<Readmore/>}></Route>
     </Routes>
    
 
    </div>
  );
}

export default App;
