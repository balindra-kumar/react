import {useLocation, useParams,useNavigate } from "react-router-dom";


 function Readmore(props){
    const params = useParams();
    let {id} = params;
    const location = useLocation();
    let {myState} = location;
    let category;
    let navigate = useNavigate();
    return(
        <div>
           
        {
            //console.log('readmore data page',location.state.myState)
            location.state.myState && location.state.myState.length>0 ?(
                <div>
                    {
                      location.state.myState.map((e)=>{
                        
                        if(e.id==id){
                            return(
                                
                                <div>{category=e.post_cat}
                                    <p>{e.post_cat}</p>
                                    <h2>{e.post_title}</h2>
                                    <p>{e.post_desc}</p>
                                    <p><button onClick={()=>navigate(-1)}>Go to Back</button></p>
                                </div>
                            )
                        }
                    })
                }

                {
                        location.state.myState.map((e)=>{
                          if(e.post_cat==category && e.post_cate!=category){
                              return(
                                  <div>
                                     
                                      <h2>{e.post_cat}</h2>
                                      <p>{e.post_title}</p>
                                     
                                  </div>
                              )
                          }
                      })
                    }
                   
                </div>
            ):
            (
                <div>sadf</div>
            )

        }
        </div>
    )
}
export default Readmore;