// ItemList.js
import React,{ useEffect  } from 'react';

import { useDispatch, useSelector } from 'react-redux';
import { fetchData } from './fetchingData';
import { NavLink } from 'react-router-dom';

export function ItemList(){

  const dispatch = useDispatch();
  const data = useSelector((state)=>state.items);
  
  useEffect(()=>{
    dispatch(fetchData());
  },[dispatch])
  console.log("checking data", data.items)
  return(
    <div>
    <h1>Data from Redux Store</h1>
   



    {
    data.items && data.items.length > 0 ?(
     <ul>
      {
        data.items.map((item)=>(
          <li key={item.id}>{item.post_title} <NavLink to={'/readmore/' + item.id} className="btn btn-sm btn-success p-1" state={{ myState: data.items }}>Read More</NavLink></li>
        ))
      }
     </ul>
    )
    :(
      <p><img src="https://media.tenor.com/guhB4PpjrmUAAAAM/loading-loading-gif.gif" width="100" style={{margin:'0 auto',display:'table'}}/></p>
    ) 
    }
     
  </div>
  )
}
export default ItemList;