// actions.js
import axios from 'axios';
import { fetchItems } from './actions';

// export const fetchItemsFromServer = () => {
 
// };




export const fetchData = () => {
  return (dispatch) => {
    dispatch(fetchItems());
    axios.get('http://balindra.com/post/read.php') // Replace with your API endpoint
      .then((response) => {
        const data = response.data;
        dispatch(fetchItems(data));
        console.log(data)
      })
     
  };
};
