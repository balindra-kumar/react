// store.js
import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunkMiddleware  from 'redux-thunk'; // Optional middleware for async actions
import itemReducer from './reducers';

// Combine reducers if you have multiple reducers
const rootReducer = combineReducers({
  items: itemReducer,
  // Add other reducers here if needed
});

const store = createStore(rootReducer, applyMiddleware(thunkMiddleware));

export default store;