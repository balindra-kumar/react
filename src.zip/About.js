import { useState } from "react";
function About() {
  const [count,setCount]=useState(1);
  function updateCounter(){
    let randValue = Math.floor(Math.random()*10);
   setCount((pre)=>{
    console.log(pre)
    if(pre<2){
      prompt("hello")
    }
    return randValue
   })
  }
  return (
    <div>     
       <div>About Us page Works</div>
       <p>Your Counter is {count}</p>
        <button onClick={updateCounter}>Counter Update</button>

      



    </div>

  )
}

export default About;