
import './App.scss';
import {Routes, Route}  from 'react-router-dom';
import Nav from './navbar/Nav';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Users from './student/Users';
import UserDetails from './student/UserDetails';
import Apihit from './student/Apihit'
import EmployeeCreate from './student/EmployeeCreate';
import Pagenotfound from './Pagenotfound'

function App() {
  

  
  return (
    <div className="App">
     
       {<Nav/>}
     
       <Routes>
      
        <Route path=""></Route>
        <Route path="/about" element={<About/>}></Route>
        <Route path="/contact" element={<Contact/>}></Route>
        <Route path="/home" element={<Home/>}></Route>
        <Route path="/users" element={<Users/>}></Route>
        <Route path="/users/:id" element={<UserDetails/>}></Route>
        <Route path="/apihit" element={<Apihit/>}></Route>
        <Route path="/employee" element={<EmployeeCreate/>}></Route>
        <Route path="/*" exact={true} element={<Pagenotfound/>}></Route> 
        
       </Routes>
      
       
     
       
      
    </div>
  );
  
  

}

export default App;
