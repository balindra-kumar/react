
function Contact(){
    return(
      <div>Contact Us page Works</div>
    )
  }
  export default Contact;