

function Home(){
    return(
      <div>
        Home page works
      </div>
    )
  }

  export default Home;