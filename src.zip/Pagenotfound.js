

function Pagenotfound(){
    return(
        <div className="pagenotfound">
            <h1>Page Not Found</h1>
        </div>
    )
}
export default Pagenotfound;