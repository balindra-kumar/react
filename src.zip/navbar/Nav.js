import React from 'react';
import { NavLink } from "react-router-dom";

function Nav() {
    return (
        <div>
            <div className="navbar-area">

                <nav className='navbar navbar-expand-lg bg-dark' data-bs-theme="dark">
                    <div className='container'>
                        <div className='navbar-header'>
                            <NavLink to="/" className="navbar-brand">Logo Name</NavLink>
                        </div>
                        <ul className="navbar-nav my-auto">
                            <li className="nav-item">
                                <NavLink to="/home" className='nav-link'>Home</NavLink>
                            </li>

                            <li className="nav-item">
                                <NavLink to="/about" className='nav-link'>About</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to="/users" className='nav-link'>Users</NavLink>
                            </li>

                            <li className="nav-item">
                                <NavLink to="/contact" className='nav-link'>Contact Us</NavLink>
                            </li>
                                                         
                        </ul>
                    </div>
                </nav>


            </div>
        </div>
    )
}

export default Nav;