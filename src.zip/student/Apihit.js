import { useEffect, useState } from "react";
import {NavLink} from 'react-router-dom';

function Apihit(){
   
   const [data,setData]=useState([]);
  
   useEffect(()=>{
    GetPost()
    
    },[])


    function GetPost(){
        fetch("http://localhost:8080/api-crud/api/api-crud/post/read.php").then((result)=>{
            result.json().then((data)=>{
               let obj=data;
                setData(obj)
                console.log(obj)
            })
    })
    }

    function deleteRecord(id){
        fetch(`http://localhost:8080/api-crud/api/api-crud/post/delete.php?id=${id}`,{
         method:'DELETE'
        }).then((resultData)=>{
          resultData.json().then((resp)=>{
            console.log(resp)
            GetPost()
          })
        })
      }
    
    
    return(
        <div className="container mx-auto">
            <h3>Api Fetch Data </h3>
            <div>
              {
                data.map((e)=>{
                    return(
                        <div className="row">
                            <div className="col-md-1">{e.id}</div>
                            <div className="col-md-6">{e.post_title}</div>
                            {/* <div className="col-md-2"><NavLink to={e.post_url}>Read More</NavLink></div> */}
                            <div className="col-md-2"><NavLink to="/users">Read More</NavLink></div>
                            <div className="col-md-2"> <NavLink onClick={()=>deleteRecord(e.id)} className="btn btn-sm bg-success">Delete</NavLink></div>
                        </div>
                )
              })}
            </div>
        </div>
    )
}
export default Apihit;