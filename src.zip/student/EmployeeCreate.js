import { useNavigate } from "react-router-dom"
import { useState } from "react";


function EmployeeCreate(){
   
    const navigate = useNavigate();
    const [post_title,setPostTitle]=useState('');
    const [post_meta_desc,setPostMetaDesc]=useState('');
    const [post_url,setPostUrl]=useState('');
    const [file,setPostImg]=useState(null);


    const handleFileChange = (event) => {
        setPostImg(event.target.files[0]);
      };
    


    // let data = {post_title,post_meta_desc,post_url,post_img}

    
    // async function postSubmit(e){
    //     e.preventDefault();
          
    //     fetch("http://localhost:8080/api-crud/api/api-crud/post/post.php",{method:'post',
    //     headers:{'Accept':'Application/json','Content-Type':'Application/json'},
    //     body:JSON.stringify(data)}).then((result)=>{
    //         console.log("Result",result);
    //     },[])
    //     // navigate("/users")
    // }


  const postSubmit = async (s)=>{
    s.preventDefault();
    const formData = new FormData();
    formData.append('post_title',post_title);
    formData.append('post_meta_desc',post_meta_desc);
    formData.append('post_url',post_url);
    formData.append('file',file);

    try{
        const resp = await fetch("http://localhost:8080/api-crud/api/api-crud/post/post.php",{
            method:'post',
            body:formData
        });
       

    }catch(error){
        console.log(error);
    }
  }

    



    return(
        <div className="container mt-3">
            <form method="post" onSubmit={postSubmit}>
                <div className="row mb-1">
                    <label className="col-md-1">post_title</label>
                    <div className="col-md-2"> <input type="text" value={post_title} onChange={(e)=>{setPostTitle(e.target.value)}} name="post_title" /></div>
                </div>
                <div className="row mb-1">
                    <label className="col-md-1">post_meta_desc</label>
                    <div className="col-md-2"> <input type="text" value={post_meta_desc} onChange={(e)=>{setPostMetaDesc(e.target.value)}} name="post_meta_desc" /></div>
                </div>
                <div className="row mb-1">
                    <label className="col-md-1">post_url</label>
                    <div className="col-md-2"> <input type="text" name="post_url" value={post_url} onChange={(e)=>{setPostUrl(e.target.value)}} /></div>
                </div>
                <div className="row mb-1">
                    <label className="col-md-1">Post Img</label>
                    <div className="col-md-2"> <input type="file" name="file" onChange={handleFileChange} /></div>
                </div>
                <div className="row">
                    <div className="col-md-3">
                        <div className="float-end mt-2">
                        <input type="submit" value="submit"/>
                        </div>
                    </div>
                </div>
            </form>
            <button onClick={()=>{navigate(-1)}} className="border bg-dark text-white p-1">Back</button>
        </div>
    )
}

export default EmployeeCreate