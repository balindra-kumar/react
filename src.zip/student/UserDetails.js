import { useLocation, useParams, useNavigate } from "react-router-dom";

function UserDetails() {
    const location = useLocation();
    const { myState } = location.state;

    const params = useParams();
    let { id } = params;

    const navigate = useNavigate();

    const matchData = myState.map((userDetailData) => {
        if (userDetailData.id == id) {
            return (
                <div className="card container">
                    <div className="card-header">
                        <h3>{userDetailData.id}</h3>
                    </div>
                    <div className="card-body">
                        <ul>
                            <li>{userDetailData.post_title}</li>
                            <li>{userDetailData.post_meta_desc}</li>
                            <li>{userDetailData.post_url}</li>
                        </ul>
                    </div>

                    <button onClick={(() => navigate(-1))}>Go to back</button>
                </div>
            )
        }

    })

    return (
        <div>
            <h3>User Details</h3>
            <ul>
                {matchData}
            </ul>
        </div>
    )
}
export default UserDetails;