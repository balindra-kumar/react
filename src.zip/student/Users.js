import { useEffect, useState } from 'react';
import { NavLink,useNavigate } from 'react-router-dom';


function Users() {

    let [post, setPost] = useState([])
    let [postData, setData] = useState()

    const [SearchKeyword,setSearchKeyword]=useState()
  
    const [post_title, setPostTitle] = useState('')
    const [post_meta_desc, setPostMetaDesc] = useState('')
    const [post_url, setPostUrl] = useState('')
    const [file, setPostImg] = useState(null);
    const [updateId, setUpdateId] = useState('')
    const [img, setImg]=useState(file)

    const navigate = useNavigate()

    const handleFileChange = (e) => {
        setImg(URL.createObjectURL(e.target.files[0]))
        setPostImg(e.target.files[0])

        // let setImg = e.target.files[0];

    }
 


    let c = post.sort((a, b) => {
        return b.id - a.id
    })

    useEffect(() => {
       
        getPost();
        setData(c)
    }, [])

    function getPost() {
        fetch("http://localhost:8080/api-crud/api/api-crud/post/read.php").
        then((res) => {
           return res.json();
        }).
        then((resp) => {
                setPost(resp)
                let filterRes=resp.sort((a, b) => {
                return b.id - a.id
            })
               setData(filterRes);

            }).catch(err=>{
                console.log(err);
            })
        
    }

    function deletePost(id) {
        fetch(`http://localhost:8080/api-crud/api/api-crud/post/delete.php?id=${id}`, {
            method: 'DELETE'
        }).then((result) => {
            result.json().then((resp) => {
                alert("Your One Record is Deleted")
                getPost()
            })
        })
    }

    function updateData(updateId) {
        c.map((u) => {
            if (u.id == updateId) {
                setPostTitle(u.post_title)
                setPostMetaDesc(u.post_meta_desc)
                setPostUrl(u.post_url)
                setImg('http://localhost:8080/api-crud/api/api-crud/post/'+u.post_img)
                setPostImg(file)
                setUpdateId(u.id)
                navigate("/users")
               
               
            }
        })
    }

    const updatePost = async (s) => {
        s.preventDefault();
        const formData = new FormData();
        formData.append('post_title', post_title);
        formData.append('post_meta_desc', post_meta_desc);
        formData.append('post_url', post_url);
        formData.append('file', file);

        try {
            const resp1 = await fetch(`http://localhost:8080/api-crud/api/api-crud/post/update.php?id=${updateId}`, {
                method: 'POST',
                body: formData
            }); 
            
            getPost()
            let myModalEl = document.getElementById('updateData')
            myModalEl.classList.remove('show');
            myModalEl.setAttribute('aria-hidden', 'true');
            myModalEl.setAttribute('style', 'display: none');
            const modalBackdrops = document.getElementsByClassName('modal-backdrop');

                //Remove opened modal backdrop
                document.body.removeChild(modalBackdrops[0]);

        } catch (error) {
            console.log(error);
        }

    }

    // function search(searchKeyword) {

    //   let searchKey = searchKeyword.toLowerCase();
    //   setData(searchKey)

    // //   let searchData = c.filter((dataFilter)=>{
    // //     dataFilter.post_title.toLowerCase().includes(searchKey);
    // //   })

    // let s = c.filter(ds=>ds.post_title.toLowerCase().includes(postData))
    
    // }

    // const userData = c.map((e) => {
    //     let f = e.post_title.charAt(0);


    //     function colorChange() {
    //         if (f.toLowerCase() == 'A'.toLowerCase() || f.toLowerCase() == 'w'.toLowerCase()) {
    //             return ({ 'color': '#000', 'background': '#ff00003b' })
    //         }
    //         else if (f.toLowerCase() == 'S'.toLowerCase()) {
    //             return ({ 'color': '#000', 'background': '#00000021' })
    //         }
    //     }
    // })



        let searchK=(sk)=>{
            
            setSearchKeyword(sk)
          
            const filterData = c.filter((g) => g.post_title.toLowerCase().includes(sk.toLowerCase()))
             setData(filterData);
       }
    //    if(searchK!=="undefined"){
    //     console.log(c)
    //     setData(c)
    // }

   
   

    


    return (
        <div className="container">
            <nav className="navbar-expand-lg navbar">
                <ul className='navbar-nav me-auto flex-row'>

                    <li className="nav-item">
                        <NavLink to="/employee" className="nav-link border bg-primary text-white">Create Post</NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink to="/apihit" className="nav-link border bg-warning">View Post</NavLink>
                    </li>

                </ul>
                <ul>
                    <li className="m-l-3"><input type="text" onKeyUp={(k) => searchK(k.target.value)} placeholder='Search the user name....' className="form-control" /></li>
                </ul>
            </nav>
            <table className="table table-bordered border">
                <thead>
                <tr className="bg-success text-white">
                    <th>User Id</th>
                    <th>User Image</th>
                    <th>User Name</th>
                    <th>User City</th>
                    <th>User Mobile</th>
                    <th>Get Details</th>
                    <th>Delete Post</th>
                    <th>Update Post</th>
                </tr>
                </thead><tbody>
                {
                     postData?.map((e)=>{
                        return (

                            <tr key={e.id}>
                                <td>{e.id}</td>
                                <td><div style={{ 'width': '100px', 'height': '70px', 'overflow': 'hidden' }}><img src={`http://localhost:8080/api-crud/api/api-crud/post/${e.post_img}`} style={{ 'width': '100%' }} /></div></td>
                    
                                <td>
                    
                                    {e.post_title}</td>
                                <td>{e.post_meta_desc}</td>
                                <td>{e.post_url}</td>
                                <td><NavLink to={'/users/' + e.id} className="btn btn-sm btn-success p-1" state={{ myState: post }}>Read More</NavLink></td>
                                <td><NavLink onClick={() => deletePost(e.id)} className="btn btn-sm btn-success p-1" >Delete</NavLink></td>
                    
                                <td>
                                    <div>
                    
                                        <div> <NavLink onClick={() => updateData(e.id)} className="btn btn-sm btn-primary p-1" data-bs-toggle="modal" data-bs-target="#updateData">Update</NavLink></div>
                                        <div id="updateData" className="modal fade" tabIndex="-1" data-bs-backdrop="static">
                                            <div className="modal-dialog modal-dialog-centered">
                                                <div className="modal-content">
                                                    <div className="modal-header">
                                                        <h3>Update Data</h3>
                                                        <button className="btn btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div>
                                                        <form method="post" onSubmit={updatePost}>
                                                            <div className="row mb-1">
                                                                <label className="col-md-4">post_title</label>
                                                                <div className="col-md-8"> <input type="text" value={post_title} onChange={(e) => { setPostTitle(e.target.value) }} name="post_title" /></div>
                                                            </div>
                                                            <div className="row mb-1">
                                                                <label className="col-md-4">post_meta_desc</label>
                                                                <div className="col-md-8"> <input type="text" value={post_meta_desc} onChange={(e) => { setPostMetaDesc(e.target.value) }} name="post_meta_desc" /></div>
                                                            </div>
                                                            <div className="row mb-1">
                                                                <label className="col-md-4">post_url</label>
                                                                <div className="col-md-8"> <input type="text" name="post_url" value={post_url} onChange={(e) => { setPostUrl(e.target.value) }} /></div>
                                                            </div>
                                                            <div className="row mb-1">
                                                                <label className="col-md-4">Post Img</label>
                                                                <div className="col-md-8"> <input type="file" name="file" onChange={handleFileChange} /></div>
                                                                <img src={`${img}`} width="100"/>
                                                            </div>
                                                            <div className="row">
                                                                <div className="col-md-3">
                                                                    <div className="float-end mt-2">
                                                                        <input type="submit" value="submit" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                    
                    
                                </td>
                            </tr>
                    
                 )
                     })}
                    
                    
                    </tbody>
            </table>
          


        </div>
    )

    
}
export default Users;